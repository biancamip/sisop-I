#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

/* Uma função que falcula os números de Fibonacci. */
int fibo(int n) {
   if (n <= 1)
      return n;
   else 
      return fibo(n-2) + fibo(n-1);
}

int main(int argc, char** argv) {
   int resultado = 0;
   int arg = 5;
   int meu_pid = -1;

   /* este código (uma vez compilado) será executado por um processo. 
    * Vamos determinar qual é o PID do processo (tal como definido
    * em _tempo de execução_!):
    */
   meu_pid = getpid();
   resultado = fibo(arg);
   printf("Fibo(%d) = %d\n", arg, resultado);
   printf("Um resultado oferecido pelo processo de PID %d.\n", meu_pid);
   printf("Terminei de executar. Vou agora para um mundo melhor...\n");
   return(0);
}
