#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {
   printf("O programa foo executando...\n");
   return(0);
}
