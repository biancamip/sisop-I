Os exercícios a seguir são puramente indicativos. Podem ser feitos, ou não, e
na ordem que mais interessa a cada estudante. De forma geral, seguem a ordem
de aula (fork -> wait -> pipe). 


1) Como "introdução", pode-se baixar, compilar e executar os programas usados na última aula.
Para compilar os programas, pode-se usar o arquivo 'Makefile' fornecido, com comandos (na linha de comando do terminal) do tipo:
> make
> make all
> make clean (para apagar os executáveis)

Pode-se também usar simplesmente o comando típico:
> gcc -o ex1-fork-v1 ex1-fork-v1.c

Uma vez compilado o programa pode-se executá-lo da forma seguinte:
> ./ex1-fork-v1


2) A partir dos programas que ilustram o uso de getpid() e de fork(), mais a
chamada getppid() (de uso similar a getpid(), mas que retorna o PID do
processo pai), programar o comportamento seguinte:
  - Um processo principal cria sucessivamente dois filhos.
  - Cada processo filho cria seu próprio filho.
  - Obtem-se desta forma 5 processos em execução.
  - Cada um dos cinco processos deve imprimir na tela:
     - Seu PID,
     - o PID de seu pai,
     - Os PIDs de seus processos filhos.

3) Programar, a partir dos exemplos, a criação de um processo "avô", que cria
dois processos "filhos" A e B. Um dos processos filhos (A) deve criar 3 filhos
(netos do processo inicial). O outro processo filho (B) deve criar 2 filhos.
Com chamadas wait() ou waitpid(), garantir a ordem de execução seguinte:
 - o processo avô deve esperar para finalizar sua execução que seus dois filhos A e B tenham terminado.
 - A deve esperar para terminar sua execução até que seu segundo filho tenha terminado.
 - Um dos filhos de B deve terminar sua execução antes de B. O outro pode terminar depois de B, ou antes.

4) Ler, compilar, executar e entender o conteudo de 'pipe.c'. Fazer as
alterações sugeridas nos comentários iniciais do arquivo.

5) A partir do arquivo 'ex4-pipe-v1.c', experimentar as variações seguintes:
   - aumentar o tamanho dos dados escritos/lidos em um dos pipes (por exemplo:
     aumente o tamanho do string escrito). Chega-se a um limite? O que acontece?

   - usar mais chamadas de 'fork' para criar novos processos (5, por exemplo),
e usar pipes entre os processos para que uma informação inicializada por
um dado processo seja repassada aos poucos a todos os demais processos. Por
exemplo, o processo parente pode inicializar 'val' a um certo valor, e 'val'
deve ser comunicado a todos os demais processos.


6) 'ex0-getpid.c' inclui um programa recursivo (Fibonnacci). Cada chamada a 'fibo' efetua recursivamente duas chamadas a 'fibo'.
A partir deste exemplo, escrever um programa multiprocessado que inicia com um
processo parente. Este vai chamar "fork()" para se "clonar". Logo depois, o
processo parente deve efetuar uma chamada recursiva a fibo(), e o processo
filho deve efetuar a outra chamada recursiva. Quando o parente tiver terminado
sua execução recursiva de fibo(), ele deve esperar pelo fim da execução do
processo filho. O filho deve comunicar o resultado de seu cálculo ao seu
parente (pode usar um pipe; pode escrever em um arquivo, que o pai lê...),
antes de finalizar sua execução. Quando o parente é liberado de esperar pelo
filho, deve recuperar o resultado calculado pelo filho, e somá-lo ao resultado
que ele mesmo calculou.

(Observação extra: assim como se pode querer, sequencialmente, limitar chamadasrecursivas para não mais fazer recursão quando o parâmetro fica muito pequeno, também se pode querer evitar de criar processos novos quando o parâmetro (de Fibo()) se torna pequeno.)


