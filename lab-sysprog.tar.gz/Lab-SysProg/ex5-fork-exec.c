#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(void)
{
	pid_t   pid;

	pid = fork() ;
	if(pid != 0) { /* Executado pelo processo pai */
      printf("Pai executando... Criei o processo de pid: %d\n", pid);
	}
	else { /* executado pelo processo filho */
     execv("./foo", NULL) ; /* passa a executar o binário 'foo' */
     printf("Oi mundo do processo filho!\n"); /* Isso nunca será executado! */
	}
   return(0);
}
