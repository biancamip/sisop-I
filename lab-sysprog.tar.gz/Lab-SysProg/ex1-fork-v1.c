#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main(void)
{
	pid_t retorno_do_fork;  
  // AQUI
   printf("Tem um processo.\n");
	retorno_do_fork = fork() ;

   printf("Oi - deve ter dois processos executando isso.\n");

   /* A partir daqui, dois processos executam o que segue. Porém, a um processo fork() retornou 0; 
    * ao outro, fork() retornou um valor não-zero. É a única forma de diferenciar os dois processos.
    */
	if(retorno_do_fork != 0) { /* Sou o pai */
	   printf("OI! Sou o processo pai. Acabei de me clonar.\n");
	   printf("Sou o processo pai. Sei que sou o pai, pois o fork() me retornou o valor %d, que difere de zero. Este valor é o PID de meu filho!\n", retorno_do_fork);
	   printf("Sou o processo pai. Meu filho / clone está executando este mesmo if(), mas não está cláusula e sim o else().\n");
	}
	else { /* retorno_do_fork == 0, isso será executado apenas pelo processo filho (clone). */
	   printf("Salut! Sou o processo filho (clone). Acabei de ser clonado.\n");
	   printf("Sou o processo filho (clone). Sei que sou o filho pois o fork() me retornou o valor 0.\n");
	   printf("Sou o processo filho (clone). Estou executando este mesmo if(), mas estou na cláusula else(), justamente porque tive o retorno 0 de fork().\n");
	} 
   printf("Sou um processo de PID == %d, e meu pai tem PID == %d\n", getpid(), getppid());
   return(0);
}
