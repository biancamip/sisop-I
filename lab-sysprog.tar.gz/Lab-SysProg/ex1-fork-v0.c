#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main(void)
{
	pid_t res = -1;
   pid_t pid = -1;
  // AQUI
   printf("Tem um processo.\n");
   res = getpid();
   printf("O PID do processo 1, antes do fork, é: %d.\n", res);
	res = fork() ;
   printf("Oi - deve ter dois processos executando isso.\n");
   if (res == 0) { // esta clausula sera executada pelo filho.
      int pid_pai;
     pid = getpid();
     pid_pai = getppid();
     printf("Eu sou o filho. Meu PID eh: %d. O PID de meu pai é %d.\n", pid, pid_pai);
   }
   else { // executado pelo processo pai.
     pid = getpid();
     printf("Eu sou o parente. Meu PID eh: %d. o PID do meu filho é %d.\n", pid, res);
     // for (int j=0 ; j<10000000 ; j++) res++;

}


   return(0);
}
