Este diretório inclui exemplos de manipulação de processos em C:
 - Criação (fork),
 - wait e waitpid,
 - pipe para comunicação,
 - fork/exec (chama 'foo').
