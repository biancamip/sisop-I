1) Para compilar, entre outras opções, você pode digitar:
make all 
no terminal.

2) Os arquivos lista.h e lista.c especificam e implementam uma estrutura de
dados de lista encadeada de structs, que representam cada uma uma mensagem.
Além da struct, têm vários procedimentos que possibilitam manipular a lista. Os
dois mais importantes são os que serializam e deserializam a lista.

3) O arquivo teste-lista.c implementa dois testes de uso de lista.h. Ele lê
dados contidos no arquivo 'input-teste-lista.txt'. Este arquivo pode servir
como exemplo de uso das listas.

4) O arquivo pipe2.c contem uma nova comunicação por pipe entre dois processos
(não mais entre quatro, como era o caso de pipe.c). A mensagem a ser comunicada
não é mais um 'int val = 10', e sim uma lista de mensagens. O programa mostra
como se serializa/deserializa a lista para comunicá-la.

5) A implementação da lista em arquivos separados leva a um processo de
compilação em separado de vários arquivos, com dependências entre si, seguido
da amarração (link edition) final dos arquivos objetos .o gerados pela
compilação separada de cada .c para obter um executável único final.
Basicamente, para gerar o executável 'pipe2' ou 'teste-lista', deve-se compilar
com o flag -c cada arquivo .c, e no fim gerar o binário. Alguma coisa como:
gcc -c lista.c
gcc -c pipe2.c
gcc -o pipe2 lista.o pipe2.o

(cada arquivo XXX.o é gerado por um comando gcc -c XXX.c).
O Makefile dá conta disso, e digitar
make pipe2
ou
make teste-lista
ou
make all
dá o mesmo resultado.

6) Para limpar todos os arquivos gerados pela compilação, digitar:
make clean
Sobram então apenas os arquivos fontes originais.
make all
recompila tudo do zero.
