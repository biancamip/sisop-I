/*
 * Estrutura de dados de lista, com alguns procedimentos
 * para sua manipula��o.
 *
 * Este arquivo � o "header" a incluir. A implementa��o dos procedimentos se
 * encontra em lista.c
 * Para usar estes procedimentos em um arquivo 'main.c':
 * 1) #incluir este arquivo lista.h no cabe�alho de main.c
 * 2) compilar com:
 *      gcc -c main.c
 *      gcc -c lista.c
 *      gcc main.o lista.o -o xxxx
 * 3) o execut�vel 'xxxx' ser� gerado e pode ser executado depois.
 *
 * Cf. 'teste-lista.c' para um exemplo de uso.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>

struct msg_t {
   int msg_id;
   char * words;
   int words_s;
   struct msg_t * next;
};

/* Construtor de uma mensagem.
 * Uma 'mensagem' � tamb�m um elemento de uma lista encadeada.
 * Neste construtor, s� se cria um elemento da lista, sem encadear
 * este elemento em outra parte da lista. O usu�rio precisa ajustar
 * o ponteiro 'next' depois da chamada ao construtor.
 */
struct msg_t * newMsg(int id, char* palavras ) ; 

/* Insere uma mensagem como novo elemento no in�cio de uma lista de mensagens.
 * 'msg_list' � a refer�ncia sobre a lista. Ao retornar, o procedimento ter�
 * atualizado msg_list para apontar para o elemento inserido, que � o novo
 * primeiro na lista.
 * 'm' � a mensagem a ser inserida.
 */
void addMsgToList(struct msg_t * m, struct msg_t * * msg_list) ;

/* Insere uma mensagem como novo elemento no fim de uma lista de mensagens.
 * 'msg_list' � a refer�ncia sobre a lista. 
 * 'm' � a mensagem a ser inserida.
 */
void appendMsgToList(struct msg_t * m, struct msg_t * * msg_list) ;


/* Inverte a ordem dos elementos numa lista de mensagens.
 */
void revertList(struct msg_t * * msg_list) ;

/* Retorna o n�mero de elementos (mensagens) na lista.
 */
int sizeList(struct msg_t * msg_list) ;

/* Imprime na tela o conteudo da lista.
 */
void printListOfMsgs(struct msg_t * msg_list) ;

/* Percorre a lista de mensagens, e copia seu conte�do byte por byte dentro
 * de uma �rea cont�gua na mem�ria (chamada 'buffer'). 
 * o procedimento retorna o n�mero de Bytes ocupados no buffer pela c�pia de 
 * cada campo de todos os elementos da lista.
 * Argumentos:
 *  'buffer': um ponteiro para o in�cio da �rea na mem�ria aonde copiar os
 *            elementos da lista. Notar que o procedimento aloca a mem�ria
 *            necess�ria. 'buffer' n�o precisa ter sido alocado anteriormente.
 *  'msg_list': a lista de mensagens a percorrer e serializar.
 */
int serializeListOfMsgs(char** buffer, struct msg_t * msg_list) ;

/* Desempacota mensagens a partir do buffer passado em argumento.
 * Argumentos:
 * 'buffer' : o buffer (sequ�ncia de bytes) de onde ler as mensagens.
 * 'buf_size': o tamanho, em Bytes, do buffer.
 * 'msg_list': uma refer�ncia sobre uma lista de mensagens. � um argumento 'out', que
 *             contem, no retorno, a lista de mensagens lidas do buffer.
 * Retorno: o procedimento retorna o n�mero de mensagens lidas do buffer, ou seja
 *          o tamanho da lista 'msg_list'.
 */
int unserializeListOfMsgs(char* buffer, int buf_size, struct msg_t ** msg_list) ;
