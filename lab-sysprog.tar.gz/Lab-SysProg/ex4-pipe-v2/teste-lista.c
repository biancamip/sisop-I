#include "lista.h"

/*
 * Teste da estrutura de dados de lista, com alguns procedimentos
 * para sua manipula��o.
 * S�o dois testes:
 *  1) com uma lista pequena de tr�s elementos,
 *  2) com uma lista maior, cujas mensagens s�o lidas de um arquivo 'input-teste-lista.txt'.
 */



int main(void)
{
    char* buffer;
    int buf_size;
    struct msg_t * messages;
    struct msg_t * messages_transmitidos;
    int nb_msg;
    FILE* input;
    int nb_lines = 96;
    char * linha = NULL;
    size_t len = 0;
    int size, i;

    printf("================= TESTE 1 =====================\n");
    messages = newMsg(15, "Hello there!");
    addMsgToList( newMsg(16, "Bom dia!"), &messages );
    addMsgToList( newMsg(17, "Bonjour!"), &messages );
    printf("Tenho a lista de Msgs:\n");
    printListOfMsgs(messages);
    buf_size = serializeListOfMsgs(&buffer, messages);
    nb_msg = unserializeListOfMsgs(buffer, buf_size, &messages_transmitidos);
    printf("Deserializacao feita.\n");
    if ( sizeList(messages) == nb_msg )
       printf("Boa noticia: a lista extraida do buffer tem o mesmo tamanho como a lista serializada no buffer.\n");
    else 
       printf("Ma noticia: a lista extraida do buffer tem tamanho %d, que e diferente do tamanho da lista serializada no buffer (%d elementos).\n", nb_msg, sizeList(messages));
    printf("Tenho a lista deserializada de Msgs:\n");
    printListOfMsgs(messages_transmitidos);

    /* Teste 2 */
    printf("================= TESTE 2 =====================\n");
    input = fopen("./input-teste-lista.txt", "r");
    if (!input) {
       printf("ERRO - Arquivo ./input-teste-lista.txt nao foi encontrado.\n");
       exit(-1);
    }
    i=0;
    size = getline(&linha, &len, input);
    if (size != -1) 
       messages = newMsg(i, linha);
    i++;
    while ((size = getline(&linha, &len, input)) != -1) {
        appendMsgToList( newMsg(i, linha), &messages );
        i++;
    }
    fclose(input); 
    printf("Tenho a lista de Msgs:\n");
    printListOfMsgs(messages);
    buf_size = serializeListOfMsgs(&buffer, messages);
    nb_msg = unserializeListOfMsgs(buffer, buf_size, &messages_transmitidos);
    printf("Deserializacao feita.\n");
    if ( sizeList(messages) == nb_msg )
       printf("Boa noticia: a lista extraida do buffer tem o mesmo tamanho como a lista serializada no buffer.\n");
    else 
       printf("Ma noticia: a lista extraida do buffer tem tamanho %d, que e diferente do tamanho da lista serializada no buffer (%d elementos).\n", nb_msg, sizeList(messages));
    printf("Tenho a lista deserializada de Msgs:\n");
    printListOfMsgs(messages_transmitidos);

   return(0);
}
