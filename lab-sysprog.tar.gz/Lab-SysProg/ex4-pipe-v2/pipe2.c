/*
 * pipe.c: cria��o de processos atrav�s de fork e comunica��o atrav�s de pipes.
 *
 * Compila��o: 
 *  gcc -o pipe pipe.c
 *
 * O programa gera quatro processos, em forma de �rvore, atrav�s do comando 
 * fork(). Ap�s gerado os processos, o processo 0 envia o conteudo da variavel
 * 'val' a demais processos, via pipe.
 * Todos os processos escrevem na tela o valor de 'val' que possuem afinal.
 * Uma representa��o da �rvore de processos pode ser vista na figura abaixo
 *
 *
 *                       0 processo inicial
 *                       | fork()
 *                     /  \
 *                    /    \
 *      processo pai 0     0.1 processo filho
 *                   |      |
 *           fork() / \    /  \ fork()
 *                 0  0.2 0.1 0.1.1
 *                 |  |   |   |
 *      processo pai  |   |   processo filho do processo filho
 *                    |   |
 *       processo filho  processo pai
 *        2 do pai
 *
 * Tarefas:
 * - Testar o funcionamento do programa e entender seu comportamento.
 * - Alterar o programa para fazer com que ap�s todos os processos recebam
 *   'val' tal como enviado inicialmente pelo processo 0.
 * - Alterar a mensagem a ser enviada pelo(s) pipe(s) para usar a struct msg_t fornecida
 *   (ver os exemplos de uso no in�cio do main()).
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>

#include "lista.h"

int main(void)
{
    int     fd[2], fd2[2], nbytes;
    pid_t   pid1, pid2;
    int val = 0 ;
    char* buffer;
    int buf_size;
    struct msg_t * messages;
    struct msg_t * messages_transmitidos;
    int nb_msg;

    pipe(fd);
    pipe(fd2);

    pid1 = fork() ;
    if(pid1 != 0) { /* Sou o pai (proc 0) */

       /* Vamos agora comunicar uma lista de mensagens, por meio do pipe */
       messages = newMsg(15, "Hello there!");
       addMsgToList( newMsg(16, "Bom dia!"), &messages );
       addMsgToList( newMsg(17, "Bonjour!"), &messages );
       /* Serializo a lista de mensagens, para poder depois envi�-la
        * por meio de um pipe.
        */
       buf_size = serializeListOfMsgs(&buffer, messages);

       write(fd2[1], &buf_size, sizeof(buf_size));
       write(fd[1], buffer, buf_size);
       /* Nota-se na linha acima que n�o mudou quase nada.
        * S� se serializou a lista encadeada de mensagens em um 
        * buffer, antes de envi�-lo. E foi necess�rio enviar (no pipe
        * fd2 o tamanho do buffer, pois este n�o ser� conhecido do lado
        * do receptor).
        */
       printf("Proc 0 - enviei as mensagens:\n");
       printListOfMsgs(messages);
    }
    else { /* Processo filho 1 (proc 0.1) */
        /* Primeiro l� o tamanho do buffer... */
        nbytes = read(fd2[0], &buf_size, sizeof(buf_size));
        /* Depois, aloca a mem�ria necess�ria para receber o buffer */
        buffer = (char*)malloc(buf_size*sizeof(char));
        /* Depois l� o buffer do pipe */
        nbytes = read(fd[0], buffer, buf_size);
        /* Por fim, de-seraliza o buffer para recuperar uma lista de msgs */
        nb_msg = unserializeListOfMsgs(buffer, buf_size, &messages_transmitidos);
        printf("Proc 0.1 - recebi as mensagens:\n");
        printListOfMsgs(messages_transmitidos);
    }
   return(0);
}
