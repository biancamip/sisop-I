#include "lista.h"
/*
 * Estrutura de dados de lista, com alguns procedimentos
 * para sua manipula��o. Este arquivo contem a implementa��o dos procedimentos.
 * cf. lista.h para as estruturas de dedos e declara��es.
 * Cf. 'teste-lista.c' para um exemplo de uso.
 *
 * A ser compilado em separado com:
 *    gcc -c lista.c
 * Este comando gerar� o c�digo objeto em 'lista.o'
 */

/* Construtor de uma mensagem.
 * Uma 'mensagem' � tamb�m um elemento de uma lista encadeada.
 * Neste construtor, s� se cria um elemento da lista, sem encadear
 * este elemento em outra parte da lista. O usu�rio precisa ajustar
 * o ponteiro 'next' depois da chamada ao construtor.
 */
struct msg_t * newMsg(int id, char* palavras ) {
   struct msg_t * m = (struct msg_t *) malloc( sizeof(struct msg_t) );
   m->msg_id = id;
   m->words_s = strlen(palavras)+1;
   m->words = (char*)malloc(m->words_s * sizeof(char));
   strcpy(m->words, palavras);
   m->next = NULL;
   return(m);
}

/* Insere uma mensagem como novo elemento no in�cio de uma lista de mensagens.
 * 'msg_list' � a refer�ncia sobre a lista. Ao retornar, o procedimento ter�
 * atualizado msg_list para apontar para o elemento inserido, que � o novo
 * primeiro na lista.
 * 'm' � a mensagem a ser inserida.
 */
void addMsgToList(struct msg_t * m, struct msg_t * * msg_list) {
   m->next = *msg_list;
   *msg_list = m; 
}

/* Insere uma mensagem como novo elemento no fim de uma lista de mensagens.
 * 'msg_list' � a refer�ncia sobre a lista. 
 * 'm' � a mensagem a ser inserida.
 */
void appendMsgToList(struct msg_t * m, struct msg_t * * msg_list) {
   struct msg_t * element, * last;
   element = *msg_list;
   /* Varre toda a lista at� o fim, mantendo um ponteiro sobre o 
    * ultimo elemento.
    */
   while (element) {
      last = element;
      element = element->next;
   }
   /* Altera o 'next' do �ltimo elemento para apontar para o elemento a inserir. */
   last->next = m;
}


/* Inverte a ordem dos elementos numa lista de mensagens.
 */
void revertList(struct msg_t * * msg_list) {
   struct msg_t * m_before = NULL;
   struct msg_t * m_curr = NULL; 
   struct msg_t * m_after = NULL; 

   m_curr = *msg_list;
   while (m_curr) {
      m_after = m_curr->next;
      m_curr->next = m_before;
      m_before = m_curr;
      m_curr = m_after;
   }
   *msg_list = m_before;
}

/* Retorna o n�mero de elementos (mensagens) na lista.
 */
int sizeList(struct msg_t * msg_list) {
   int size=0;
   struct msg_t * m = msg_list;
   while (m) {
      size++;
      m = m->next;
   }
   return(size);
}

/* Imprime na tela o conteudo da lista.
 */
void printListOfMsgs(struct msg_t * msg_list) {
   struct msg_t * m = msg_list;
   while (m) {
      printf("{id: %d, texto: %s}\n", m->msg_id, m->words);
      m = m->next;
   }
}

/* Percorre a lista de mensagens, e copia seu conte�do byte por byte dentro
 * de uma �rea cont�gua na mem�ria (chamada 'buffer'). 
 * o procedimento retorna o n�mero de Bytes ocupados no buffer pela c�pia de 
 * cada campo de todos os elementos da lista.
 * Argumentos:
 *  'buffer': um ponteiro para o in�cio da �rea na mem�ria aonde copiar os
 *            elementos da lista. Notar que o procedimento aloca a mem�ria
 *            necess�ria. 'buffer' n�o precisa ter sido alocado anteriormente.
 *  'msg_list': a lista de mensagens a percorrer e serializar.
 */
int serializeListOfMsgs(char** buffer, struct msg_t * msg_list) {
   struct msg_t * m = msg_list;
   int mem_size = 0;
   int list_size = 0;
   int buffer_index = 0;
   int nb_bytes;
   /* 
    * Percorre uma primeira vez a lista de mensagens para determinar o tamanho
    * necess�rio na mem�ria para copiar seu conteudo. Aproveita o la�o para tamb�m
    * contar as mensagens na lista (= o tamanho da lista).
    */
   while (m) {
      list_size++;
      mem_size += sizeof(m->msg_id) + sizeof(m->words_s) + m->words_s * sizeof(char);
      m = m->next;
   }
   /* Aloca a mem�ria necess�ria ao buffer */
   *buffer = (char*)malloc(mem_size * sizeof(char));
   /* faz um novo percurso da lista, desta vez para copiar cada campo dos elementos 
    * da lista, de forma cont�gua, no buffer.
    */
   m = msg_list;
   buffer_index=0;
   while (m) {
      /* Usa memcpy para ser mais gen�rico. Pode-se usar tamb�m aritm�tica de ponteiro, em vez de
       * '&(buffer[buffer_index])'.
       */
      nb_bytes = sizeof(m->msg_id);
      memcpy(*buffer+buffer_index, &(m->msg_id), nb_bytes);
      buffer_index += nb_bytes;
      nb_bytes = sizeof(m->words_s);
      memcpy(*buffer+buffer_index, &(m->words_s), nb_bytes);
      buffer_index += nb_bytes;
      nb_bytes = m->words_s * sizeof(char);
      memcpy(*buffer+buffer_index, m->words, nb_bytes);
      buffer_index += nb_bytes;
      m = m->next;
   }
   if (buffer_index < mem_size)
      printf("Fim da serializacao. Copiei %d Bytes no buffer, que e inferior ao tamanho do buffer (%d Bytes). Alguma coisa deu errado.\n", buffer_index, mem_size);
   else if (buffer_index > mem_size)
      printf("Fim da serializacao. Copiei %d Bytes no buffer, que e superior ao tamanho do buffer (%d Bytes). Alguma coisa deu errado.\n", buffer_index, mem_size);
   return(mem_size);
}

/* Desempacota mensagens a partir do buffer passado em argumento.
 * Argumentos:
 * 'buffer' : o buffer (sequ�ncia de bytes) de onde ler as mensagens.
 * 'buf_size': o tamanho, em Bytes, do buffer.
 * 'msg_list': uma refer�ncia sobre uma lista de mensagens. � um argumento 'out', que
 *             contem, no retorno, a lista de mensagens lidas do buffer.
 * Retorno: o procedimento retorna o n�mero de mensagens lidas do buffer, ou seja
 *          o tamanho da lista 'msg_list'.
 */
int unserializeListOfMsgs(char* buffer, int buf_size, struct msg_t ** msg_list) {
   int id;
   int words_s;
   int msg_nb = 0;
   char* palavras;
   int buffer_index = 0;

   /* Percorre o buffer, de seu Byte inicial at� seu fim, para ler dele
    * de forma iterativa cada parte de uma mensagem.
    */
   *msg_list = NULL;
   buffer_index=0;
   msg_nb = 0;
   while(buffer_index < buf_size) {
     /* Copy do buffer, successivamente, cada campo de uma struct msg_t */
     memcpy(&id, buffer+buffer_index, sizeof(int));   /* 1) um msg_id */
     buffer_index += sizeof(int);
     memcpy(&words_s, buffer+buffer_index, sizeof(int));  /* 2) o word_s */
     buffer_index += sizeof(int);
     palavras = (char*)malloc((words_s+1)*sizeof(char));
     memcpy(palavras, buffer+buffer_index, words_s*sizeof(char));  /* 3) o string */
     buffer_index += words_s*sizeof(char);
     palavras[words_s] = '\0';
     /* Concatena na lista sendo (re)criada a mensagem que foi extra�da do buffer */
     addMsgToList( newMsg(id, palavras), msg_list );
     msg_nb++;
   }
   /* A lista obtida � invertida. Reordena-a na ordem certa. */
   revertList(msg_list);
   return(msg_nb);
}

