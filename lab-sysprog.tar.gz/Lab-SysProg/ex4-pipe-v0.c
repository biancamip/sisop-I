#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>

int main(void)
{
    int     canal[2];  /* O "cano" (pipe): l� em canal[0], escreve em canal[1] */
    int  nbytes;
    pid_t   pid;
    int val = 0 ;

    /* Inicializa��o dos pipes */
    pipe(canal);     

    val = -1;
    pid = fork() ; // Neste ponto, os dois processos t�m val = -1.

    if(pid != 0) { /* o pai executa o seguinte */
	    printf("Proc pai - Antes do envio, val = %d\n", val);
       val = 10 ;
	    printf("Proc pai - Envio val = %d\n", val);
       write(canal[1], &val, sizeof(int));
       printf("Proc pai - Enviei val = %d ao meu filho.\n", val);
    }
    else { /* o filho executa o seguinte */
	   printf("Proc filho - Antes da recepcao, val = %d\n", val);
		nbytes = read(canal[0], &val, sizeof(val));
	   printf("Proc filho - Val recebido do pai = %d\n", val);
	}
   return(0);
}
