#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>

int main(void)
{
    int     canal[2];  /* O "cano" (pipe): l� em canal[0], escreve em canal[1] */
    int     canal2[2]; /* Outro 'pipe' */
    int     canal3[2]; /* Mais um 'pipe'... */
    int  nbytes;
    pid_t   pid;
    char    messagem[80];
    int val = 0 ;
    int tamanho = 0;

    /* Inicializa��o dos pipes */
    pipe(canal);     
    pipe(canal2);
    pipe(canal3);

    val = -1;
    pid = fork() ; // Neste ponto, os dois processos t�m val = -1.

    if(pid != 0) { /* o pai executa o seguinte */
	    printf("Proc pai - Antes do envio, val = %d\n", val);
       val = 10 ;
	    printf("Proc pai - Envio val = %d\n", val);
       write(canal[1], &val, sizeof(int));
       /* Agora, o pai espera receber uma mensagem do filho... */
       printf("Proc pai - Vou esperar uma mensagem de meu filho.\n");
       nbytes = read(canal2[0], &tamanho, sizeof(tamanho));
       printf("Proc pai - Recebi de meu filho o tamanho da mensagem que ele me enviara depois (%d Bytes).\n", tamanho);
       nbytes = read(canal3[0], messagem, sizeof(char)*tamanho);
       printf("Proc pai - Recebi de meu filho a messagem: %s.\n", messagem);
    }
    else { /* o filho executa o seguinte */
	   printf("Proc filho - Antes da recepcao, val = %d\n", val);
		nbytes = read(canal[0], &val, sizeof(val));
	   printf("Proc filho - Val recebido do pai = %d\n", val);
      /* Agora envia um string ao pai */
      strcpy(messagem, "Obrigado, pai!");
      tamanho = strlen(messagem);
      write(canal2[1], &tamanho, sizeof(int));
	   printf("Proc filho - enviei para o pai o tamanho da messagem (%d Bytes) que vou enviar agora.\n", tamanho);
      write(canal3[1], messagem, sizeof(char)*tamanho);
	   printf("Proc filho - enviei para o pai a messagem: %s\n", messagem);
	}
   return(0);
}
