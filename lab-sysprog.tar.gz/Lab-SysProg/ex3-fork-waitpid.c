#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(void)
{
	pid_t   pid1,pid2;
	FILE* arquivo;
   int status1, status2;

	arquivo = fopen("output.txt", "w"); // Abre um arquivo para escrever nele.
	pid1 = fork() ;
   /*
      |
      +----------+
      |          |
      |          |
    pid1!=0       pid1 == 0
      |          |
      +--+       |
      |  |       |
      |  |       |
pid2!=0 pid2=0
      |  |

      */
	if(pid1 != 0) { /* Sou o pai */

	   pid2 = fork() ;
	   if(pid2 != 0) {

      waitpid(pid2, &status2, 0); /* Espera por meu filho de pid 'pid2' */

	   /* Escreve alguma coisa no arquivo */
	   fprintf(arquivo, "... Mundo!");
	   }
	   else {
	   /* Escreve alguma coisa no arquivo */
      waitpid(pid1, &status1, 0); /* Espera por meu filho de pid 'pid2' */
	   fprintf(arquivo, "E Ola!...");
	   }
	}
	else { 

      // wait(&status1);

	   /* Escreve alguma coisa no arquivo */
	   fprintf(arquivo, "Hello!...");
	}
   printf("Eu sou o processo de PID %d\n", getpid());
   fclose(arquivo); // Fecha o arquivo.
   return(0);
}
