#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(void)
{
	pid_t   pid1,pid2;
	FILE* arquivo;
   int status1, status2;

	arquivo = fopen("output.txt", "w"); // Abre um arquivo para escrever nele.
	pid1 = fork() ;
	if(pid1 != 0) { /* Sou o pai */
	   pid2 = fork() ;
	   if(pid2 != 0) {

      wait(&status2);  // Bloqueia até o fim de qualquer um dos filhos.

       wait(&status1);
	   /* Escreve alguma coisa no arquivo */
	   fprintf(arquivo, "... Mundo!");
	   }
	   else {
	   /* Escreve alguma coisa no arquivo */
	   fprintf(arquivo, "E Ola!...");
	   }
	}
	else { 
	   /* Escreve alguma coisa no arquivo */
	   fprintf(arquivo, "Hello!...");
	}
   printf("Eu sou o processo de PID %d\n", getpid());
   fclose(arquivo); // Fecha o arquivo.
   return(0);
}
