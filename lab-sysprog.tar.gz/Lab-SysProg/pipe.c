/*
 * pipe.c: cria��o de processos atrav�s de fork e comunica��o atrav�s de pipes.
 *
 * Compila��o: 
 *  gcc -o pipe pipe.c
 *
 * O programa gera quatro processos, em forma de �rvore, atrav�s do comando 
 * fork(). Ap�s gerado os processos, o processo 0 envia o conteudo da variavel
 * 'val' a demais processos, via pipe.
 * Todos os processos escrevem na tela o valor de 'val' que possuem afinal.
 * Uma representa��o da �rvore de processos pode ser vista na figura abaixo
 *
 *
 *                       0 processo inicial
 *                       | fork()
 *                     /  \
 *                    /    \
 *      processo pai 0     0.1 processo filho
 *                   |      |
 *           fork() / \    /  \ fork()
 *                 0  0.2 0.1 0.1.1
 *                 |  |   |   |
 *      processo pai  |   |   processo filho do processo filho
 *                    |   |
 *       processo filho  processo pai
 *        2 do pai
 *
 * Tarefas:
 * - Testar o funcionamento do programa e entender seu comportamento.
 * - Alterar o programa para fazer com que ap�s todos os processos recebam
 *   'val' tal como enviado inicialmente pelo processo 0.
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>

int main(void)
{
    int     fd[2], fd2[2], nbytes;
    pid_t   pid1, pid2;
    int val = 0 ;

    pipe(fd);

    pid1 = fork() ;
    pipe(fd2);
    if(pid1 != 0) { /* Sou o pai (proc 0) */
       val = 10 ;
       pid2 = fork() ;
       if(pid2 != 0) {
          /* Sou o pai */
          write(fd[1], &val, sizeof(int));
          printf("Proc 0 - Val = %d\n", val);
       }
       else { /* Sou o segundo filho do pai 0 (proc 0.2) */
          printf("Proc 0.2 - Val = %d\n", val);
       }
    }
    else { /* Processo filho 1 (proc 0.1) */
       pid2 = fork() ;
       if (pid2 != 0){
          /* sou o filho 1 */
          nbytes = read(fd[0], &val, sizeof(val));
          printf("Proc 0.1 - Val = %d\n", val);
       }
       else { /* Sou o filho do filho 1 (proc 0.1.1) */
          printf("Proc 0.1.1 - Val = %d\n", val);
       }
    }
   return(0);
}
